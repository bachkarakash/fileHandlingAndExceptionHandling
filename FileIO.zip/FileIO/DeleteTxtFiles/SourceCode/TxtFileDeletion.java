import java.io.File;
public class TxtFileDeletion 
{
	public static void main(String[] args)
	{
		File tempFile = new File("C:\\Users\\bachkar.akash\\Downloads");	//Folder from which .txt files are to be deleted
		File[] listFiles = tempFile.listFiles();	// List of files in current directory
		for(File cur:listFiles)
		{
			if(cur.getAbsolutePath().endsWith(".txt"))	// if file extension is .txt
			{
				System.out.println("Text File: "+cur.getAbsolutePath());
				boolean isdeleted = cur.delete();	// delete the file
				if(isdeleted)
				{
					System.out.println("File is deleted");
				}
				else
				{
					System.out.println("File is not deleted");
				}
			}
		}
	}

}
