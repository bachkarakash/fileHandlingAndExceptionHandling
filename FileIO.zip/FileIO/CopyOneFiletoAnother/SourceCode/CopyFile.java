import java.io.*;
public class CopyFile 
{
	public static void main(String[] args) throws IOException
	{
		FileInputStream tempFile = new FileInputStream("C:\\Users\\bachkar.akash\\Downloads\\sample.txt"); //File to  be copied
		FileOutputStream tempFile1 = new FileOutputStream("C:\\Users\\bachkar.akash\\Downloads\\copied.txt"); //File where the data is to be copied
		int cha;
		while((cha = tempFile.read())!=-1)  // While data is available
			tempFile1.write((char)cha);	//Write in another file
		
		System.out.println("File is copied");
		tempFile.close();
		tempFile1.close();
	}

}
