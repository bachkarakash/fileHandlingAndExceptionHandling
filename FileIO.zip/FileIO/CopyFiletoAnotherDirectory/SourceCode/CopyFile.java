import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
public class CopyFile 
{
	public static void main(String[] args) throws IOException
	{
		 //File where the data is to be copied
		FileInputStream tempFile = new FileInputStream("C:\\Users\\bachkar.akash\\Downloads\\sample.txt"); //File to  be copied
		FileOutputStream tempFile1 = new FileOutputStream("C:\\Users\\bachkar.akash\\Downloads\\Copy\\copied.txt"); //File where the data is to be copied (Another directory)
		int cha;
		while((cha = tempFile.read())!=-1)	// While data is available
			tempFile1.write((char)cha);	//Write in another file
		
		System.out.println("File is copied in another directory");
		tempFile.close();
		tempFile1.close();
	}

}
