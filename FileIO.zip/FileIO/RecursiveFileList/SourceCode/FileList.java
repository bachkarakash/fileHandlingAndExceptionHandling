import java.io.File;
import java.io.FileNotFoundException;
public class FileList 
{
	public void recursiveList(String path)
	{
		File dir = new File(path);				// File sent to this function 
		File[] listFiles = dir.listFiles();		// List of files in this directory
		if(listFiles == null)			//if directory is empty
		{
			return;
		}
		for(File cur:listFiles)		// List of files and directories in current directory
		{
			if(cur.isDirectory())
			{
				System.out.println("Directory: "+cur.getAbsoluteFile());
				recursiveList(cur.getAbsolutePath());		// Go inside the directory
			}
			else
			{
				System.out.println("File: "+cur.getAbsoluteFile());
			}
			
		}
	}
	public static void main(String[] args) throws FileNotFoundException
	{
		FileList fList = new FileList();
		fList.recursiveList("C:\\Users\\bachkar.akash\\Downloads");
	}
}
