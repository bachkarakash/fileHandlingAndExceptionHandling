import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class BasicExceptionExample 
{
	public static void main(String[] args) throws FileNotFoundException
	{
		
			Scanner sc = new Scanner(System.in);
			//Arithmetic Exception
			int a,b;
			System.out.println("Enter value of a and b");
			a = sc.nextInt();
			b = sc.nextInt();	//Enters 0
			int res = a/b;
			
			//ArrayIndexOutOfBoundException
			int arr[] = new int[5];
			int n;
			System.out.println("Enter value of n");
			n = sc.nextInt(); //Enters value greater than 5
			
			for(int i=0;i<n;i++)
			{
				System.out.println(arr[i]);
			}
			
			//FileNotFoundException
			File file = new File("C:\\Users\\bachkar.akash\\Downloads\\sampl.txt"); // File is not present
			FileInputStream fIn = new FileInputStream(file);
		
		
	}

}
