import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

public class Logfile 
{
	public static void main(String[] args) throws SecurityException, IOException
	{
		Logger log = Logger.getLogger("Logging");
		FileHandler fileHandle;
		try
		{
			Scanner sc = new Scanner(System.in);
			//Arithmetic Exception
			int a,b;
			System.out.println("Enter value of a and b");
			a = sc.nextInt();
			b = sc.nextInt();	//Enters 0
			int res = a/b;
			
			//ArrayIndexOutOfBoundException
			int arr[] = new int[5];
			int n;
			System.out.println("Enter value of n");
			n = sc.nextInt(); //Enters value greater than 5
			
			for(int i=0;i<n;i++)
			{
				System.out.println(arr[i]);
			}
			
			//FileNotFoundException
			File file = new File("C:\\Users\\bachkar.akash\\Downloads\\sampl.txt"); // File is not present
			FileInputStream fIn = new FileInputStream(file);
		}
		catch(ArithmeticException e)
		{
			//Log file for Arithmetic Exceptions
			fileHandle = new FileHandler("ArithmeticException.log");
			log.addHandler(fileHandle);	//// Log file handler
			log.severe(e.toString());
			log.fine(e.toString());
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			//Log file for ArrayIndexOutOfBounds Exceptions
			fileHandle = new FileHandler("ArrayIndexOutOfBoundsException.log");
			log.addHandler(fileHandle);	//// Log file handler
			log.severe(e.toString());
			log.fine(e.toString());
		}
		catch(FileNotFoundException e)
		{
			//Log file for FileNotFoundException
			fileHandle = new FileHandler("FileNotFoundException.log");
			log.addHandler(fileHandle);	// Log file handler
			log.severe(e.toString());
			log.fine(e.toString());
		}
		catch(Exception e)
		{
			fileHandle = new FileHandler("Exception.log");
			log.addHandler(fileHandle);	//// Log file handler
			log.severe(e.toString());
			log.fine(e.toString());
		}
	}

}
